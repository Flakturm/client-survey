-- Adminer 4.2.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `company`;
CREATE TABLE `company` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `geo_zone_id` int(11) NOT NULL,
  PRIMARY KEY (`company_id`),
  KEY `geo_zone_id` (`geo_zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `company` (`company_id`, `name`, `website`, `logo`, `geo_zone_id`) VALUES
(1,	'Sonepar Asia Pacific Limited',	'www.sonepar.com',	'son_019942',	1),
(2,	'Sonepar China',	'www.sonepar.com.cn',	'son_010850',	2),
(3,	'Elektroskandia (Shanghai) Co., Ltd',	'www.elektroskandia.com.cn',	'son_023571',	2),
(4,	'Electric Fever Co., Ltd',	'www.electricfever.cn',	'son_023491',	2),
(5,	'Foshan Shunching Supermoon Trading Co., Ltd',	'www.scsupermoon.com',	'FSS-Logo',	2),
(6,	'Hagemeyer Commerce & Trade (Shanghai) Co., Ltd',	'www.hagemeyercn.com',	'son_023569',	2),
(7,	'Beijing Hagemeyer Fengruite Trading Co., Ltd',	'www.hagemeyercn.com',	'son_023569',	2),
(8,	'Hite Electric Technology Co., Ltd',	'www.hite-electric.com',	'son_023568',	2),
(9,	'Shanghai Jiayi Industry Co., Ltd',	'www.jiayi.sh.cn',	'son_025555',	2),
(10,	'Shunmoon (Shanghai) Lighting Limited',	'',	'shunmoon',	2),
(11,	'WitJoint Electrical Technology (Shanghai) Co., Ltd.',	'www.witjoint.com',	'son_023576',	2),
(12,	'Supermoon Holdings Ltd.',	'www.supermoon.hk',	'son_023574',	1),
(13,	'Min Kwong Electric (H.K.) Co., Ltd.',	'www.supermoon.hk',	'son_023574',	1),
(14,	'Hip Tung Cables Company Limited',	'www.hiptung.com',	'son_025542',	1),
(15,	'Sonepar South-East Asia',	'www.sonepar.com',	'son_024801',	4),
(16,	'Hagemeyer Malaysia PPS Pte Ltd',	'www.hagemeyerasia.com',	'son_023572',	4),
(17,	'KVC Industrial Supplies SDN. BHD.',	'www.kvc.com.my',	'son_019872',	4),
(18,	'Total Industrial Solutions (M) Sdn Bhd   ',	'www.totalkl.com',	'son_023582',	4),
(19,	'Skyline Technology (M) SDN. BHD.',	'www.skyline-tech.com.my',	'son_023579',	4),
(20,	'Syarikat See Wide Letrik Sdn. Bhd.',	'www.seewide.com.my',	'son_023581',	4),
(21,	'Electplus Industry Sdn. Bhd',	'www.electplus.com',	'ElectPlus',	4),
(22,	'Interstate M & E Sdn. Bhd.',	'www.interstate.com.my',	'son_024457',	4),
(23,	'Interstate Solutions Bhd',	'www.interstate.com.my',	'son_024457',	4),
(24,	'Sun Power Automation Sdn. Bhd.',	'www.sunpowerberhad.com.my',	'son_025541',	4),
(25,	'Cable Solutions (Thailand) Inc.',	'www.cablesolutions.com.sg ',	'son_023573',	3),
(26,	'Hagemeyer PPS (Thailand) Ltd.',	'www.hagemeyerasia.com',	'son_023572',	3),
(27,	'Sonic Automation Ltd.',	'www.sonicautomation.co.th',	'son_023580',	3),
(28,	'DEP Engineering Co., Ltd.',	'www.depdis.com',	'son_023578',	3),
(29,	'ETS-OAKWELL Co. Ltd.',	'www.ets-oakwell.com',	'son_025537',	3),
(30,	'Cable Solutions & Electrical (Sea) Pte Ltd.',	'www.cablesolutions.com.sg ',	'son_023573',	5),
(31,	'Hagemeyer Asia',	'www.hagemeyerasia.com',	'son_023572',	5),
(32,	'Hagemeyer Singapore PPS PTE Ltd',	'www.hagemeyerasia.com',	'son_023572',	5),
(33,	'HoST Pte Ltd',	'www.host.sg/',	'son_025399',	5),
(34,	'Oakwell Distribution (S) Pte. Ltd.',	'www.oakwell.com.sg',	'son_023955',	5),
(35,	'Dilon Trading (S) Pte Ltd',	'www.oakwell.com.sg',	'son_023955',	5),
(36,	'M&I Electric Far East Pte Ltd',	'www.mielectric.com.sg',	'son_025974',	5),
(37,	'\"Oakwell International Trading (Shanghai) Co., Ltd \"',	'www.oakwell.com.sg',	'son_023955',	5),
(38,	'Oakwell Engineering (M) Sdn Bhd',	'www.oakwell.com.sg',	'son_023955',	5),
(39,	'Oakwell Korea Co., Ltd',	'www.oakwell.com.sg',	'son_023955',	6),
(40,	'Oakwell Engineering (Vietnam) Company Limited',	'www.oakwell.com.sg',	'son_023955',	7),
(41,	'Oakwell Engineering Equipment (Shanghai) Co., Ltd',	'www.oakwell.com.sg',	'son_023955',	2),
(42,	'PT Fanah Jaya Maindo',	'',	'son_023583',	8),
(43,	'PT Cable Solutions Indonesia',	'www.cablesolutions.com.sg ',	'son_023573',	8),
(44,	'ESK Telecom',	'www.eskindia.in',	'son_025553',	11),
(45,	'ESK Automation',	'www.eskautomation.com',	'son_023531',	11),
(46,	'Sonepar Pacific',	'www.sonepar.com',	'son_024799',	9),
(47,	'L&H Group',	'www.landhgroup.com.au',	'son_017193',	9),
(48,	'Auslec',	'www.auslec.com.au',	'son_025392',	9),
(49,	'Lawrence & Hanson',	'www.lh.com.au',	'son_017192',	9),
(50,	'Pacific Datacom',	'www.pacificdatacom.com.au',	'son_017194',	9),
(51,	'Specialised Lighting Solutions',	'www.slsgrp.com.au',	'son_017195',	9),
(52,	'L&H Solar + Solutions',	'lhsps.com.au',	'son_017197',	9),
(53,	'Smarter Clothing',	'www.smarterclothing.com.au',	'son_017196',	9),
(54,	'Electrical Wholesale Services',	'http://ewsco.com.au/',	'son_025975',	9),
(55,	'Electrical Distributor of Western Australia',	'www.electricaldistributors.com.au',	'son_024778',	9),
(56,	'Corys Electrical Ltd',	'www.corys.co.nz',	'son_019888',	10);

DROP TABLE IF EXISTS `emails`;
CREATE TABLE `emails` (
  `email_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) NOT NULL,
  `company` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `feedback_comment` text,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `feedback_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `language` varchar(255) NOT NULL,
  PRIMARY KEY (`email_id`),
  KEY `feedback_id` (`feedback_id`),
  KEY `company` (`company`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `email_template`;
CREATE TABLE `email_template` (
  `email_template_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`email_template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `email_template` (`email_template_id`, `name`) VALUES
(1,	'English'),
(2,	'template 2'),
(3,	'template 3');

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `email_id` int(11) NOT NULL,
  KEY `email_id` (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `feedback` (`feedback_id`, `email_id`) VALUES
(2,	4),
(1,	5),
(2,	10);

DROP TABLE IF EXISTS `feedback_description`;
CREATE TABLE `feedback_description` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `feedback_description` (`feedback_id`, `description`) VALUES
(1,	'like'),
(2,	'can_do_better');

DROP TABLE IF EXISTS `files`;
CREATE TABLE `files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_orig_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email_id` int(11) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `geo_zone`;
CREATE TABLE `geo_zone` (
  `geo_zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `language_id` int(11) NOT NULL,
  PRIMARY KEY (`geo_zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `geo_zone` (`geo_zone_id`, `name`, `language_id`) VALUES
(1,	'HONG KONG SAR',	6),
(2,	'CHINA, PRC',	5),
(3,	'THAILAND',	4),
(4,	'MALAYSIA',	1),
(5,	'SINGAPORE',	1),
(6,	'KOREA',	2),
(7,	'VIETNAM',	1),
(8,	'INDONESIA',	3),
(9,	'AUSTRALIA',	1),
(10,	'NEW ZEALAND',	1),
(11,	'INDIA',	1);

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1,	'admin',	'Administrator'),
(2,	'members',	'General User');

DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `language_id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `languages` (`language_id`, `language`) VALUES
(1,	'english'),
(2,	'korean'),
(3,	'indonesian'),
(4,	'thai'),
(5,	'zh_cn'),
(6,	'zh_tw');

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` int(11) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1,	'127.0.0.1',	'administrator',	'$2y$08$9/N/wd7DGVaHFcZ0.RwFkOWCWzakNrCg8vMDD5xwjE359y1AIwol.',	'',	'admin@admin.com',	'',	NULL,	NULL,	'B76lGeIbcS.ydisnH76aie',	1268889823,	1467969788,	1,	'Admin',	'istrator',	1,	'0');

DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`),
  CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1,	1,	1);

-- 2016-07-08 09:23:53
